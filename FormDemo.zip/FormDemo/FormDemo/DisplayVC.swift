//
//  DisplayVC.swift
//  FormDemo
//
//  Created by Suraj Prasad on 06/04/19.
//  Copyright © 2019 Suraj Prasad. All rights reserved.
//

import UIKit

class DisplayVC: UIViewController {
    //MARK:- IBOutlets
    @IBOutlet weak var displayFirstName: UILabel!
    @IBOutlet weak var displayLastName: UILabel!
    @IBOutlet weak var displayEmail: UILabel!
    //MARK:- Global Variables
    var getFirstName:String?
    var getLastName:String?
    var getEmail:String?
    //MARK:- Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        guard let setFirstName = getFirstName, let setLastName = getLastName, let setEmail = getEmail else{ return }
        displayFirstName.text = setFirstName
        displayLastName.text = setLastName
        displayEmail.text = setEmail
    }
    //MARK:- IBActions
    @IBAction func tapLogout(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
