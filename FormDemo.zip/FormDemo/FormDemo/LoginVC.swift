//
//  LoginVC.swift
//  FormDemo
//
//  Created by Suraj Prasad on 05/04/19.
//  Copyright © 2019 Suraj Prasad. All rights reserved.
//

import UIKit
import CoreData

class LoginVC: UIViewController {
    //MARK:- IBOutlets
    @IBOutlet weak var loginEmail: UITextField!
    @IBOutlet weak var loginPassword: UITextField!
    //MARK:- Global Variables
    var firstName = ""
    var lastName = ""
    var email = ""
    //MARK:- Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
  //MARK:- Helper Methods
  //function that sets default Values
    func defaultValues(){
        loginEmail.text = ""
        loginPassword.text = ""
    }
    //sending data to DisplayVC
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let vc = segue.destination as? DisplayVC {
            vc.getFirstName = firstName
            vc.getLastName = lastName
            vc.getEmail = email
        }
    }
    //MARK:- IBActions
    @IBAction func tapLoginWithEmail(_ sender: Any) {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        let fetchUser = NSFetchRequest<NSFetchRequestResult>.init(entityName: "User")
        let predicateUserEmail = NSPredicate(format: "email = %@", loginEmail.text ?? "abc@gmail.com")
        fetchUser.predicate = predicateUserEmail
        do {
            let resultUser = try context.fetch(fetchUser)
                if resultUser.count > 0{
                let manageUser = resultUser[0] as! NSManagedObject
                let obj = manageUser as? User
                if loginPassword.text == obj?.password {
                self.firstName = obj?.firstname ?? "N/A"
                self.lastName = obj?.lastname ?? "N/A"
                self.email = obj?.email ?? "defaultmail@gmail.com"
              }
                else
                {
                    let alert = UIAlertController(title: "Alert", message:"Password Incorrect" , preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
                    self.present(alert, animated: true)
                }
            }
            else {
                
                let alert = UIAlertController(title: "Alert", message:"Email Invalid or Not Registered" , preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
                self.present(alert, animated: true)
            }
             defaultValues()
             self.performSegue(withIdentifier: "DisplayVC", sender: self)
        } catch { print("unable to login")}
       
    }
    @IBAction func backToSignUpPage(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
